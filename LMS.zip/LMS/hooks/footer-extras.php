<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.1.0
    </div>
    
    <strong> Libray Management System &nbsp; &copy; <?php echo date ('Y'); ?></a> </strong>
	

  </footer>
